// import React from "react";
// import BlogImg1 from "../images/blog-img-1.png";
// import BlogImg2 from "../images/blog-img-2.png";
// import BlogImg3 from "../images/blog-img-3.png";

// const Blog = () => {
//   return (
//     <div className="blog container">
//       <h2>Blogs Posts</h2>
//       <hr></hr>

//       <div class="container">
//         <div class="row py-2">
//           <div class="col-12 col-sm-12 col-md-6 col-lg-4 py-5">
//             <div class="card">
//               <img
//                 class="card-img"
//                 src="https://cdn.pixabay.com/photo/2015/07/11/23/00/bottle-841431_1280.jpg"
//                 alt="Bologna"
//               />
//               <div class="card-img-overlay">
//                 {/* <a href="#" class="btn btn-light btn-sm">Cooking</a> */}
//               </div>
//               <div class="card-body">
//                 <h4 class="card-title py-3"> baby bottle </h4>
//                 <small class="text-muted cat px-3">
//                   <i class="far fa-clock text-info "></i> 30 minutes
//                   <i class="fas fa-users text-info pl-2"></i>{" "}
//                   <span className="px-1"> 4 portions</span>
//                 </small>
//                 <p class="card-text py-2">
//                   Versions of the Lorem ipsum text have been used in typesetting
//                   at least since the 1960s, when it was popularized by
//                   advertisements for Letraset transfer sheets.[1]
//                 </p>
//                 <a href="#" class="btn btn-info">
//                   explore
//                 </a>
//               </div>
//               <div class="card-footer text-muted d-flex justify-content-between bg-transparent border-top-0">
//                 <div class="views">Oct 20, 12:45PM</div>
//                 <div class="stats">
//                   <i class="far fa-eye"></i> 1347
//                   <i class="far fa-comment"></i> 12
//                 </div>
//               </div>
//             </div>
//           </div>
//           <div class="col-12 col-sm-12 col-md-6 col-lg-4 py-5">
//             <div class="card">
//               <img
//                 class="card-img"
//                 src="https://cdn.pixabay.com/photo/2015/07/11/23/00/bottle-841431_1280.jpg"
//                 alt="Bologna"
//               />
//               <div class="card-img-overlay">
//                 {/* <a href="#" class="btn btn-light btn-sm">Cooking</a> */}
//               </div>
//               <div class="card-body">
//                 <h4 class="card-title py-3"> baby bottle </h4>
//                 <small class="text-muted cat px-3">
//                   <i class="far fa-clock text-info "></i> 30 minutes
//                   <i class="fas fa-users text-info pl-2"></i>{" "}
//                   <span className="px-1"> 4 portions</span>
//                 </small>
//                 <p class="card-text py-2">
//                   Versions of the Lorem ipsum text have been used in typesetting
//                   at least since the 1960s, when it was popularized by
//                   advertisements for Letraset transfer sheets.[1]
//                 </p>
//                 <a href="#" class="btn btn-info">
//                   explore
//                 </a>
//               </div>
//               <div class="card-footer text-muted d-flex justify-content-between bg-transparent border-top-0">
//                 <div class="views">Oct 20, 12:45PM</div>
//                 <div class="stats">
//                   <i class="far fa-eye"></i> 1347
//                   <i class="far fa-comment"></i> 12
//                 </div>
//               </div>
//             </div>
//           </div>

//           <div class="col-12 col-sm-12 col-md-6 col-lg-4 py-5">
//       <div class="card">
//         <img class="card-img" src="https://cdn.pixabay.com/photo/2015/07/11/23/00/bottle-841431_1280.jpg" alt="Bologna"/>
//         <div class="card-img-overlay">
//           {/* <a href="#" class="btn btn-light btn-sm">Cooking</a> */}
//         </div>
//         <div class="card-body">
//           <h4 class="card-title py-3"> baby  bottle </h4>
//           <small class="text-muted cat px-3">
//             <i class="far fa-clock text-info "></i> 30 minutes
//             <i class="fas fa-users text-info pl-2"></i> <span className='px-1'> 4 portions</span>
//           </small>
//           <p class="card-text py-2">Versions of the Lorem ipsum text have been used in typesetting at least since the 1960s, when it was popularized by advertisements for Letraset transfer sheets.[1]</p>
//           <a href="#" class="btn btn-info">explore</a>
//         </div>
//         <div class="card-footer text-muted d-flex justify-content-between bg-transparent border-top-0">
//           <div class="views">Oct 20, 12:45PM
//           </div>
//           <div class="stats">
//            	<i class="far fa-eye"></i> 1347
//             <i class="far fa-comment"></i> 12
//           </div>
           
//         </div>
//       </div>

      
//     </div>

//         </div>
//       </div>
//     </div>
//   );
// };

// export default Blog;
