import react, {createContext} from "react";

const LoginContext = createContext();

export default LoginContext;